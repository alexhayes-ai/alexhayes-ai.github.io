# Bộ file mẫu cấp xã: báo cáo kết quả giải quyết thủ tục hành chính tháng 10/2026

**DỮ LIỆU GIẢ LẬP – tên xã, tên người, số liệu đều không có thật.** Không có thông tin cá nhân thật; số điện thoại đã ẩn, số định danh để trống.

## Câu chuyện
Chị Hà là chuyên viên **Văn phòng HĐND và UBND xã Phong Thạnh** (tỉnh Đông Lâm). Ngày 27/10, Văn phòng UBND tỉnh gửi Công văn 1187 yêu cầu các xã báo cáo kết quả giải quyết thủ tục hành chính tháng 10, hạn 17 giờ ngày 05/11.
Mỗi lần người dân đến xã làm giấy tờ (khai sinh, chứng thực, xin phép xây nhà…) là **một hồ sơ**. Hồ sơ được Trung tâm Phục vụ hành chính công nhận, chuyển cho phòng phụ trách xử lý, rồi trả kết quả. Hệ thống ghi ngày nhận, ngày hẹn trả, ngày trả. Báo cáo cần đếm: nhận bao nhiêu, trả bao nhiêu, đúng hạn hay quá hạn.

## Các file nối với nhau thế nào
| Thư mục | Ai gửi | Có gì | Nối với nhau bằng |
|---|---|---|---|
| 00-thong-tin-chung | Văn phòng | Danh mục lĩnh vực và phòng phụ trách | Lĩnh vực |
| 01-du-lieu-trung-tam | Trung tâm PVHCC | File xuất **6.002 dòng** hồ sơ 01/9–31/10 | Mã hồ sơ, lĩnh vực |
| 02-bao-cao-cac-phong | Phòng Kinh tế, Phòng VH-XH | Báo cáo tháng của phòng (có bản gửi lại, có phông cũ), ảnh Zalo | Lĩnh vực, mã hồ sơ |
| 03-ky-truoc | Văn phòng | Biểu 01 tháng 9 đã gửi tỉnh | Kỳ trước chuyển sang |
| 04-van-ban | Tỉnh, Văn phòng | Công văn 1187 (đề bài, có cách tính), mẫu Biểu 01–02, mẫu báo cáo, công văn, biên bản | — |
| 05-hop | Văn phòng | Ghi chú giao ban UBND xã 04/11 | Lĩnh vực, phòng |
| 98-ket-qua-chuan-sau-khi-sua | — | Biểu 01, Biểu 02 bản chuẩn, cách kiểm độc lập | — |
| 99-dap-an-dung-mo-truoc | — | Lỗi cài sẵn, đáp án hai cách tính | — |

## Cách test
Chép thư mục ra chỗ riêng (không nằm trong thư mục có CLAUDE.md khác), để 98 và 99 ra ngoài, giao việc cho Claude Code, rồi so với đáp án.
