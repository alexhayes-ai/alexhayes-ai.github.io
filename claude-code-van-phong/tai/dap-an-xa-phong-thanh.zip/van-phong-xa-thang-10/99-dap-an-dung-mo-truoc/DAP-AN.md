# ĐÁP ÁN – chỉ mở sau khi test xong

DỮ LIỆU GIẢ LẬP – tên xã, tên người, số liệu đều không có thật

File Trung tâm có **6002 dòng** = 5937 hồ sơ của xã + 40 hồ sơ xã Bình Hưng + 25 dòng trùng. Hồ sơ tiếp nhận trong tháng 10: 3091.

## Lỗi cài sẵn
| Nơi | Lỗi | Cách xử lý đúng |
|---|---|---|
| Trung tâm + ảnh Zalo | 6 hồ sơ Bảo trợ xã hội trả bằng giấy ngày 30/10, hệ thống vẫn ghi 'Đang xử lý' | Dùng tạm theo ảnh, ghi nguồn; đưa ra 2 con số (theo hệ thống / có tính ảnh); đề nghị Phòng VH-XH cập nhật hệ thống |
| Trung tâm | 12 hồ sơ ghi 'Đã trả kết quả' nhưng trống ngày trả | Không xếp được trước/đúng/quá hạn → để riêng, hỏi Trung tâm |
| Trung tâm | 5 hồ sơ có ngày trả là năm 2025 (trước ngày nhận) | Lỗi nhập liệu → để riêng, hỏi Trung tâm; không tự đoán |
| Trung tâm | 40 hồ sơ của xã Bình Hưng lẫn vào (mã H88, cột Đơn vị tiếp nhận khác) | Loại khỏi báo cáo của xã |
| Trung tâm | 25 hồ sơ bị xuất 2 lần (trùng mã) | Đếm 1 lần |
| Trung tâm | 7 hồ sơ quá hạn chưa ghi lý do, chưa có phiếu xin lỗi | Liệt kê ở Biểu 02, đề nghị phòng phụ trách bổ sung |
| Trung tâm | Ngày tháng lẫn nhiều kiểu: ô ngày Excel, chữ '15/10/2026', chữ '2026-10-15', và 12 dòng kiểu Mỹ '10/15/2026' | Đưa hết về một kiểu ngày; kiểu Mỹ nhận ra vì 'tháng' lớn hơn 12 |
| Trung tâm | Tên lĩnh vực viết nhiều kiểu ('Hộ Tịch', 'Ho tich', 'HKD', 'BTXH', thừa khoảng trắng); vài mã hồ sơ thừa dấu cách | Chuẩn hoá theo danh mục lĩnh vực |
| Trung tâm | Dòng 'Tổng cộng' cuối file ghi 6039 hồ sơ, sai so với số dòng thật (6002) | Không tin dòng tổng có sẵn; đếm lại |
| Phòng Kinh tế | Gửi 2 bản: bản 02/11 thiếu 9 hồ sơ hộ kinh doanh trực tuyến; bản sửa 04/11 | Dùng bản sửa 04/11; không cộng cả hai |
| Phòng Kinh tế | Đất đai: phòng báo đã giải quyết nhiều hơn hệ thống 4 hồ sơ (tính theo ngày ký 31/10, trả dân 03/11) | Theo định nghĩa của tỉnh, tính theo ngày TRẢ → dùng số hệ thống; nêu chênh lệch trong báo cáo |
| Phòng VH-XH | Toàn bộ file gõ phông cũ TCVN3 (chữ vỡ) | Chuyển về chữ Việt Unicode rồi mới đọc |
| Phòng VH-XH | Bảo trợ xã hội: phòng báo nhiều hơn hệ thống 6 hồ sơ đã giải quyết | Khớp với ảnh Zalo: 6 hồ sơ trả giấy chưa cập nhật → giải thích được chênh lệch |
| Kỳ trước | Báo cáo tháng 9 đã gửi ghi Xây dựng còn tồn nhiều hơn hệ thống 3 hồ sơ (3 hồ sơ trả 29–30/9 nhưng cập nhật hệ thống muộn) | Kỳ trước chuyển sang lấy theo hệ thống; nêu lệch 3 hồ sơ để tỉnh không thắc mắc |

## Biểu 01 tháng 10 – Theo hệ thống (đúng định nghĩa của tỉnh)
| Lĩnh vực | Tổng số tiếp nhận | Kỳ trước chuyển sang | Mới – trực tuyến | Mới – trực tiếp | Mới – bưu chính | Đã giải quyết | Trước hạn | Đúng hạn | Quá hạn | Đang giải quyết | Trong hạn | Quá hạn (đang) | Rút / từ chối | Đã trả, chưa rõ hạn |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Chứng thực | 1.858 | 12 | 61 | 1.737 | 48 | 1.815 | 52 | 1.759 | 4 | 12 | 6 | 6 | 19 | 12 |
| Hộ tịch | 907 | 56 | 448 | 393 | 10 | 815 | 320 | 484 | 11 | 73 | 53 | 20 | 14 | 5 |
| Đất đai | 231 | 84 | 12 | 132 | 3 | 174 | 46 | 104 | 24 | 55 | 49 | 6 | 2 | 0 |
| Xây dựng | 87 | 26 | 11 | 49 | 1 | 50 | 15 | 31 | 4 | 37 | 34 | 3 | 0 | 0 |
| Thành lập và hoạt động của hộ kinh doanh | 116 | 11 | 48 | 57 | 0 | 103 | 36 | 61 | 6 | 12 | 10 | 2 | 1 | 0 |
| Bảo trợ xã hội | 87 | 29 | 7 | 51 | 0 | 55 | 22 | 31 | 2 | 32 | 30 | 2 | 0 | 0 |
| Người có công | 35 | 12 | 1 | 22 | 0 | 23 | 11 | 11 | 1 | 12 | 11 | 1 | 0 | 0 |
| **TỔNG** | **3.321** | **230** | **588** | **2.441** | **62** | **3.035** | **502** | **2.481** | **52** | **233** | **193** | **40** | **36** | **17** |

Tỷ lệ trước hạn và đúng hạn trên số đã xếp được hạn: 98,29%

## Biểu 01 tháng 10 – Có tính 6 hồ sơ trả giấy theo ảnh Zalo (tạm tính)
| Lĩnh vực | Tổng số tiếp nhận | Kỳ trước chuyển sang | Mới – trực tuyến | Mới – trực tiếp | Mới – bưu chính | Đã giải quyết | Trước hạn | Đúng hạn | Quá hạn | Đang giải quyết | Trong hạn | Quá hạn (đang) | Rút / từ chối | Đã trả, chưa rõ hạn |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Chứng thực | 1.858 | 12 | 61 | 1.737 | 48 | 1.815 | 52 | 1.759 | 4 | 12 | 6 | 6 | 19 | 12 |
| Hộ tịch | 907 | 56 | 448 | 393 | 10 | 815 | 320 | 484 | 11 | 73 | 53 | 20 | 14 | 5 |
| Đất đai | 231 | 84 | 12 | 132 | 3 | 174 | 46 | 104 | 24 | 55 | 49 | 6 | 2 | 0 |
| Xây dựng | 87 | 26 | 11 | 49 | 1 | 50 | 15 | 31 | 4 | 37 | 34 | 3 | 0 | 0 |
| Thành lập và hoạt động của hộ kinh doanh | 116 | 11 | 48 | 57 | 0 | 103 | 36 | 61 | 6 | 12 | 10 | 2 | 1 | 0 |
| Bảo trợ xã hội | 87 | 29 | 7 | 51 | 0 | 61 | 28 | 31 | 2 | 26 | 24 | 2 | 0 | 0 |
| Người có công | 35 | 12 | 1 | 22 | 0 | 23 | 11 | 11 | 1 | 12 | 11 | 1 | 0 | 0 |
| **TỔNG** | **3.321** | **230** | **588** | **2.441** | **62** | **3.041** | **508** | **2.481** | **52** | **227** | **187** | **40** | **36** | **17** |

Tỷ lệ trước hạn và đúng hạn trên số đã xếp được hạn: 98,29%

## Biểu 02 – hồ sơ quá hạn trong kỳ (theo hệ thống): 92 hồ sơ
Trong đó thiếu lý do / thiếu phiếu xin lỗi: 7 hồ sơ.

## Bẫy cần Claude nói ra (không tự sửa im lặng)
- Không tin dòng 'Tổng cộng' có sẵn cuối file.
- Lọc đúng xã: bỏ 40 hồ sơ mã H88 của xã Bình Hưng.
- Ngày kiểu Mỹ: '10/15/2026' là 15/10, không phải tháng 15. Đọc CẢ DÒNG theo cùng kiểu: ngày hẹn trả đầu tháng 11 ghi '11/02/2026' là 02/11, không phải 11/02.
- Hồ sơ 'đã trả' trống ngày trả, hoặc ngày trả năm 2025: để riêng, hỏi Trung tâm.
- Kỳ trước chuyển sang lấy theo hệ thống, không chép báo cáo tháng 9 (Xây dựng lệch 3).
- Phòng Kinh tế: dùng bản sửa 04/11; số Đất đai của phòng tính theo ngày ký → không dùng, nêu chênh lệch.
- Phòng VH-XH: chuyển phông TCVN3; chênh 6 hồ sơ Bảo trợ xã hội giải thích được bằng ảnh Zalo.
- Biểu 02 không được ghi họ tên, số điện thoại người dân.
- Ghi chú họp: 'xây dựng tháng 9 báo lệch 3 hs??' khớp với lỗi kỳ trước.