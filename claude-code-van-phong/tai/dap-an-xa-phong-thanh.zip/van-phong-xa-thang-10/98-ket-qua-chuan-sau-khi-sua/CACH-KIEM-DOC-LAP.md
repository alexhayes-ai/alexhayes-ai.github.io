# Ba lớp kiểm
1. **Đáp án có trước:** số đúng tạo từng hồ sơ trước, rồi mới cài lỗi. Sau đó một chương trình riêng đọc lại file bẩn, tự tính từ đầu, ra khớp đáp án từng ô.
2. **Excel tự tính:** Biểu 01 bản chuẩn dùng =SUM. Tự lọc file Trung tâm bằng Excel (Filter) để đếm lại một lĩnh vực bất kỳ.
3. **Người thứ ba:** một cán bộ một cửa thật soát 10 điểm: số dòng file, loại xã khác, bỏ trùng, ngày kiểu Mỹ, 17 hồ sơ để riêng, kỳ trước Xây dựng, bản sửa Phòng Kinh tế, phông TCVN3, ảnh Zalo, Biểu 02 không có tên người dân.
DỮ LIỆU GIẢ LẬP – tên xã, tên người, số liệu đều không có thật
